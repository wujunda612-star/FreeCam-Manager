using System.IO;
using System.Diagnostics;
using System.Windows.Input;
using Microsoft.Win32;
using FreeCamManager.Core.Models;
using FreeCamManager.Core.Services;
using FreeCamManager.Services;

namespace FreeCamManager.ViewModels;

public sealed class ArtifactRowViewModel : ObservableObject
{
    public static readonly IReadOnlyList<string> ManualStatusOptions = ["未标记", "通过", "失败", "待复测", "已废弃"];

    private readonly LibraryService _library;
    private readonly OrganizerService _organizer;
    private readonly ClassificationService _classification;
    private readonly UserDialogService _dialogs;
    private readonly TestWorkspaceService _workspace;
    private readonly TestResultService _results;
    private readonly Func<string> _root;
    private readonly Func<string> _testingRoot;
    private readonly Func<string> _resultRoot;
    private readonly Action<string> _statusSink;
    private readonly Func<Task> _refreshAll;
    private readonly Func<bool> _hideFreeCamPrefix;
    private readonly Func<int> _discardAutoDeleteDays;
    private readonly Func<string, string> _translateFilename;
    private readonly Func<bool> _showFilenameAliases;
    private readonly Func<bool> _showFeatureAliases;
    private readonly Func<bool> _showStageAliases;
    private readonly Func<AppSettings> _ruleSettings;
    private Artifact _artifact;
    private string _manualStatus;
    private int _rating;
    private bool _isProtected;

    public ArtifactRowViewModel(
        Artifact artifact,
        LibraryService library,
        OrganizerService organizer,
        ClassificationService classification,
        UserDialogService dialogs,
        Action<string> statusSink,
        Func<Task> refreshAll,
        Func<bool>? hideFreeCamPrefix = null,
        Func<int>? discardAutoDeleteDays = null,
        Func<string, string>? translateFilename = null,
        Func<bool>? showFilenameAliases = null,
        Func<bool>? showFeatureAliases = null,
        Func<bool>? showStageAliases = null)
        : this(artifact, library, organizer, classification, dialogs,
            new TestWorkspaceService(new ExtractionService()), new TestResultService(new ManifestService()),
            () => organizer.Root, () => System.IO.Path.Combine(organizer.Root, "01_Testing"),
            () => System.IO.Path.Combine(organizer.Root, "40_Result"), statusSink, refreshAll, hideFreeCamPrefix, discardAutoDeleteDays, translateFilename, showFilenameAliases, showFeatureAliases, showStageAliases)
    {
    }

    public ArtifactRowViewModel(
        Artifact artifact,
        LibraryService library,
        OrganizerService organizer,
        ClassificationService classification,
        UserDialogService dialogs,
        TestWorkspaceService workspace,
        TestResultService results,
        Func<string> root,
        Func<string> testingRoot,
        Func<string> resultRoot,
        Action<string> statusSink,
        Func<Task> refreshAll,
        Func<bool>? hideFreeCamPrefix = null,
        Func<int>? discardAutoDeleteDays = null,
        Func<string, string>? translateFilename = null,
        Func<bool>? showFilenameAliases = null,
        Func<bool>? showFeatureAliases = null,
        Func<bool>? showStageAliases = null,
        Func<AppSettings>? ruleSettings = null)
    {
        _artifact = artifact.Clone();
        _library = library;
        _organizer = organizer;
        _classification = classification;
        _dialogs = dialogs;
        _workspace = workspace;
        _results = results;
        _root = root;
        _testingRoot = testingRoot;
        _resultRoot = resultRoot;
        _statusSink = statusSink;
        _refreshAll = refreshAll;
        _hideFreeCamPrefix = hideFreeCamPrefix ?? (() => false);
        _discardAutoDeleteDays = discardAutoDeleteDays ?? (() => 0);
        _translateFilename = translateFilename ?? (value => value);
        _showFilenameAliases = showFilenameAliases ?? (() => false);
        _showFeatureAliases = showFeatureAliases ?? (() => false);
        _showStageAliases = showStageAliases ?? (() => false);
        _ruleSettings = ruleSettings ?? (() => new AppSettings
        {
            LaunchRules = RuleDefaults.Launch(), DragRules = RuleDefaults.Drag()
        });
        _manualStatus = string.IsNullOrWhiteSpace(_artifact.ManualStatus) ? "未标记" : _artifact.ManualStatus;
        _rating = Math.Clamp(_artifact.Rating, 0, 5);
        _isProtected = _artifact.Protected;

        StartTestCommand = new AsyncRelayCommand(_ => StartTestAsync());
        SelectLaunchFileCommand = new AsyncRelayCommand(_ => SelectLaunchFileAsync());
        ClearLaunchFileCommand = new AsyncRelayCommand(_ => ClearLaunchFileAsync());
        SelectDragFileCommand = new AsyncRelayCommand(_ => SelectDragFileAsync());
        ClearDragFileCommand = new AsyncRelayCommand(_ => ClearDragFileAsync());
        OpenLocationCommand = new RelayCommand(_ => OpenLocation());
        OpenTestingFolderCommand = new RelayCommand(_ => OpenTestingFolder());
        OpenResultCommand = new AsyncRelayCommand(_ => OpenResultAsync());
        ReextractCommand = new AsyncRelayCommand(_ => ReextractAsync());
        DeleteTestingCommand = new AsyncRelayCommand(_ => DeleteTestingAsync());
        EditNotesCommand = new RelayCommand(_ => EditNotes());
        ToggleProtectionCommand = new RelayCommand(_ => IsProtected = !IsProtected);
        ArchiveCommand = new AsyncRelayCommand(_ => ArchiveAsync());
        DeleteVersionCommand = new AsyncRelayCommand(_ => DeleteVersionAsync());
        DeleteDuplicateCopyCommand = new AsyncRelayCommand(_ => DeleteDuplicateCopyAsync());
    }

    public string Path => _artifact.Path;
    public string Name => _artifact.Name;
    public string DisplayName
    {
        get
        {
            var value = _hideFreeCamPrefix() && Name.StartsWith("FreeCam_", StringComparison.OrdinalIgnoreCase)
                ? Name["FreeCam_".Length..]
                : Name;
            return _showFilenameAliases() ? _translateFilename(value) : value;
        }
    }
    public string Base => _artifact.Base;
    public string Feature => string.IsNullOrWhiteSpace(_artifact.Feature) ? "—" : _artifact.Feature;
    public string Stage => string.IsNullOrWhiteSpace(_artifact.Stage) ? "—" : _artifact.Stage;
    public string DisplayFeature => Feature == "—" || !_showFeatureAliases() ? Feature : _translateFilename(Feature);
    public string DisplayStage
    {
        get
        {
            var display = StageDisplayService.Format(_artifact.Stage);
            return display == "—" || !_showStageAliases() ? display : _translateFilename(display);
        }
    }
    public string CategoryLabel => _classification.CategoryLabel(_artifact);
    public string TestStatus => string.IsNullOrWhiteSpace(_artifact.TestStatus) ? "待测试" : _artifact.TestStatus;
    public string Notes => _artifact.Notes;
    public object? FileNameToolTip
    {
        get
        {
            var parts = new List<string>();
            if (_showFilenameAliases()) parts.Add($"原始文件名：{Name}");
            if (!string.IsNullOrWhiteSpace(_artifact.Notes)) parts.Add($"备注：{_artifact.Notes}");
            return parts.Count == 0 ? null : string.Join("\n\n", parts);
        }
    }
    public object? FeatureToolTip => BuildTranslatedFieldToolTip(_artifact.Feature, _showFeatureAliases());
    public object? StageToolTip
    {
        get
        {
            if (string.IsNullOrWhiteSpace(_artifact.Stage)) return null;
            var display = StageDisplayService.Format(_artifact.Stage);
            if (!_showStageAliases() && string.Equals(display, _artifact.Stage, StringComparison.Ordinal)) return null;
            var parts = new List<string> { $"原文：{_artifact.Stage}" };
            if (!string.IsNullOrWhiteSpace(_artifact.Notes)) parts.Add($"备注：{_artifact.Notes}");
            return string.Join("\n\n", parts);
        }
    }
    public object? NotesToolTip => FileNameToolTip;
    public bool IsExtracted => !string.IsNullOrWhiteSpace(ResolveTestingPath());
    public string BuildId => _artifact.BuildId;
    public string Commit => _artifact.Commit;
    public string TestingPath => _artifact.TestingPath;
    public string ResultPath => _artifact.ResultPath;
    public bool HasResult => !string.IsNullOrWhiteSpace(_artifact.ResultPath) && File.Exists(_artifact.ResultPath);
    public string ResultHint => "按设置中的拖拽规则选择文件；找不到不会自动拖 .log。右键可以单独指定。";
    public bool CanStartTest => Path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)
        && new ExtractionService().ShouldExtract(_artifact);
    public string TimeDisplay => FormatTime(_artifact.ImportedAt, _artifact.BuildDate);
    public bool IsDuplicate => string.Equals(_artifact.Category, "Duplicate", StringComparison.OrdinalIgnoreCase);
    public bool IsStable => string.Equals(_artifact.Category, "Stable", StringComparison.OrdinalIgnoreCase);
    public IReadOnlyList<string> ConclusionOptions => ManualStatusOptions;

    public string ManualStatus
    {
        get => _manualStatus;
        set
        {
            var normalized = string.IsNullOrWhiteSpace(value) ? "未标记" : value;
            if (!SetProperty(ref _manualStatus, normalized)) return;
            _artifact.ManualStatus = normalized == "未标记" ? "" : normalized;
            _library.SetManualStatus(Path, normalized);

            var saveMessage = "人工结论已保存";
            if (normalized == "已废弃")
            {
                var days = _discardAutoDeleteDays();
                if (days is 1 or 3 or 7 or 30)
                {
                    var dueAt = DateTimeOffset.Now.AddDays(days);
                    _artifact.AutoDeleteAt = dueAt.ToString("O");
                    _library.SetAutoDeleteAt(Path, dueAt);
                    saveMessage = $"已废弃 · {days} 天后自动删除";
                }
                else
                {
                    _artifact.AutoDeleteAt = "";
                    _library.ClearAutoDeleteAt(Path);
                    saveMessage = "已废弃 · 不自动删除";
                }
            }
            else
            {
                _artifact.AutoDeleteAt = "";
                _library.ClearAutoDeleteAt(Path);
            }

            _ = SaveMetadataAsync(saveMessage);
        }
    }

    public int Rating
    {
        get => _rating;
        set
        {
            var clamped = Math.Clamp(value, 0, 5);
            if (!SetProperty(ref _rating, clamped)) return;
            _artifact.Rating = clamped;
            _library.SetRating(Path, clamped);
            if (clamped == 5 && !_isProtected)
            {
                _artifact.Protected = true;
                _isProtected = true;
                OnPropertyChanged(nameof(IsProtected));
                OnPropertyChanged(nameof(ProtectionMenuText));
                _ = SaveMetadataAsync("已标记 5 星并锁定保护");
                return;
            }
            _ = SaveMetadataAsync(clamped == 0 ? "已取消标星" : $"已标记 {clamped} 星");
        }
    }

    public bool IsProtected
    {
        get => _isProtected;
        set
        {
            if (_isProtected == value) return;
            var (locked, found) = _library.ToggleProtected(Path);
            if (!found) return;
            _artifact.Protected = locked;
            SetProperty(ref _isProtected, locked);
            OnPropertyChanged(nameof(ProtectionMenuText));
            _ = SaveMetadataAsync(locked ? "已锁定保护" : "已解除保护");
        }
    }

    public ICommand StartTestCommand { get; }
    public ICommand SelectLaunchFileCommand { get; }
    public ICommand ClearLaunchFileCommand { get; }
    public ICommand SelectDragFileCommand { get; }
    public ICommand ClearDragFileCommand { get; }
    public ICommand OpenLocationCommand { get; }
    public ICommand OpenTestingFolderCommand { get; }
    public ICommand OpenResultCommand { get; }
    public ICommand ReextractCommand { get; }
    public ICommand DeleteTestingCommand { get; }
    public ICommand EditNotesCommand { get; }
    public ICommand ToggleProtectionCommand { get; }
    public string ProtectionMenuText => IsProtected ? "取消锁定" : "锁定";
    public ICommand ArchiveCommand { get; }
    public ICommand DeleteVersionCommand { get; }
    public ICommand DeleteDuplicateCopyCommand { get; }
    public ICommand DeleteCommand => DeleteVersionCommand;

    public void RefreshFromArtifact(Artifact artifact)
    {
        if (!string.Equals(artifact.Path, Path, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Cannot refresh a row from a different artifact path.", nameof(artifact));

        var manualStatus = string.IsNullOrWhiteSpace(artifact.ManualStatus) ? "未标记" : artifact.ManualStatus;
        var rating = Math.Clamp(artifact.Rating, 0, 5);
        var isProtected = artifact.Protected;
        _artifact = artifact.Clone();

        if (!string.Equals(_manualStatus, manualStatus, StringComparison.Ordinal))
        {
            _manualStatus = manualStatus;
            OnPropertyChanged(nameof(ManualStatus));
        }
        if (_rating != rating)
        {
            _rating = rating;
            OnPropertyChanged(nameof(Rating));
        }
        if (_isProtected != isProtected)
        {
            _isProtected = isProtected;
            OnPropertyChanged(nameof(IsProtected));
            OnPropertyChanged(nameof(ProtectionMenuText));
        }

        OnPropertyChanged(nameof(DisplayName));
        OnPropertyChanged(nameof(Base));
        OnPropertyChanged(nameof(Feature));
        OnPropertyChanged(nameof(Stage));
        OnPropertyChanged(nameof(DisplayFeature));
        OnPropertyChanged(nameof(DisplayStage));
        OnPropertyChanged(nameof(CategoryLabel));
        OnPropertyChanged(nameof(TestStatus));
        OnPropertyChanged(nameof(Notes));
        OnPropertyChanged(nameof(FileNameToolTip));
        OnPropertyChanged(nameof(FeatureToolTip));
        OnPropertyChanged(nameof(StageToolTip));
        OnPropertyChanged(nameof(NotesToolTip));
        OnPropertyChanged(nameof(IsExtracted));
        OnPropertyChanged(nameof(CanStartTest));
        OnPropertyChanged(nameof(BuildId));
        OnPropertyChanged(nameof(Commit));
        OnPropertyChanged(nameof(TestingPath));
        OnPropertyChanged(nameof(ResultPath));
        OnPropertyChanged(nameof(HasResult));
        OnPropertyChanged(nameof(ResultHint));
        OnPropertyChanged(nameof(TimeDisplay));
        OnPropertyChanged(nameof(IsDuplicate));
        OnPropertyChanged(nameof(IsStable));
    }

    public string GetDraggableResultPath()
    {
        var current = _library.ByPath(Path) ?? _artifact;
        var manual = File.Exists(current.DragOverridePath) ? current.DragOverridePath : "";
        if (string.IsNullOrWhiteSpace(manual) && !string.IsNullOrWhiteSpace(current.DragOverrideRelative))
        {
            var relocated = System.IO.Path.Combine(_root(), current.DragOverrideRelative);
            if (File.Exists(relocated)) manual = relocated;
        }
        return FileRuleEngine.FindDrag(current, ResolveTestingPath(), _resultRoot(),
            _ruleSettings().DragRules ?? RuleDefaults.Drag(), manual);
    }

    public void NotifyDragNotFound() =>
        _statusSink("未找到符合拖拽规则的文件；请在设置中修改规则，或右键为此版本指定文件。");

    private async Task SelectLaunchFileAsync()
    {
        try
        {
            var testing = ResolveTestingPath();
            if (string.IsNullOrWhiteSpace(testing))
            {
                if (!CanStartTest || !File.Exists(Path))
                {
                    _dialogs.Info("无法指定启动文件", "没有测试目录。请先使用可测试 ZIP 准备测试目录。");
                    return;
                }
                var prepared = await _workspace.PrepareAsync(Path, _testingRoot());
                testing = prepared.TestingPath;
                _artifact.TestingPath = testing;
                _library.SetTestingPath(Path, testing, _root());
            }
            var chosen = ChooseLaunchFile(testing);
            if (string.IsNullOrWhiteSpace(chosen)) return;
            var relative = System.IO.Path.GetRelativePath(testing, chosen);
            _library.SetLaunchOverride(Path, relative);
            _artifact.LaunchOverrideRelative = relative;
            await _library.SaveAsync();
            _statusSink("已指定启动文件: " + System.IO.Path.GetFileName(chosen));
            await _refreshAll();
        }
        catch (Exception ex) { _dialogs.Error("指定启动文件失败", ex.Message); }
    }

    private string? ChooseLaunchFile(string testing)
    {
        var picker = new OpenFileDialog
        {
            Title = "选择本版本的启动文件",
            Filter = "启动文件 (*.cmd;*.bat;*.ps1;*.exe)|*.cmd;*.bat;*.ps1;*.exe",
            InitialDirectory = testing,
            CheckFileExists = true
        };
        if (picker.ShowDialog() != true) return null;
        if (!FileRuleEngine.IsInside(picker.FileName, testing))
        {
            _dialogs.Error("路径不合法", "启动文件只能选择当前版本测试目录内的文件。");
            return null;
        }
        return picker.FileName;
    }

    private async Task ClearLaunchFileAsync()
    {
        _library.SetLaunchOverride(Path, "");
        _artifact.LaunchOverrideRelative = "";
        await _library.SaveAsync();
        _statusSink("此版本已恢复使用全局启动规则");
    }

    private async Task SelectDragFileAsync()
    {
        try
        {
            var testing = ResolveTestingPath();
            var resultRoot = _resultRoot();
            var picker = new OpenFileDialog
            {
                Title = "为本版本指定拖拽文件",
                Filter = "结果与日志 (*.zip;*.log;*.txt;*.json)|*.zip;*.log;*.txt;*.json|所有文件 (*.*)|*.*",
                InitialDirectory = Directory.Exists(testing) ? testing : resultRoot,
                CheckFileExists = true
            };
            if (picker.ShowDialog() != true) return;
            var chosen = picker.FileName;
            if (!FileRuleEngine.IsInside(chosen, testing) && !FileRuleEngine.IsInside(chosen, resultRoot))
            {
                _dialogs.Error("路径不合法", "只能指定当前测试目录或 40_Result 中的文件。");
                return;
            }
            var relative = PathRebaseService.TryMakeRelative(_root(), chosen);
            _library.SetDragOverride(Path, chosen, relative);
            _artifact.DragOverridePath = chosen;
            _artifact.DragOverrideRelative = relative;
            await _library.SaveAsync();
            _statusSink("已指定拖拽文件: " + System.IO.Path.GetFileName(chosen));
            await _refreshAll();
        }
        catch (Exception ex) { _dialogs.Error("指定拖拽文件失败", ex.Message); }
    }

    private async Task ClearDragFileAsync()
    {
        _library.SetDragOverride(Path, "", "");
        _artifact.DragOverridePath = "";
        _artifact.DragOverrideRelative = "";
        await _library.SaveAsync();
        _statusSink("此版本已恢复使用全局拖拽规则");
    }

    private async Task StartTestAsync()
    {
        if (!CanStartTest)
        {
            _dialogs.Info("此文件不是测试包", "普通资料包或源码包不自动解压启动。");
            return;
        }
        if (!File.Exists(Path))
        {
            _dialogs.Info("原始 ZIP 不存在", "这个版本的原始 ZIP 已经不在磁盘上，无法一键测试。");
            return;
        }

        TestPreparation prepared;
        try
        {
            _statusSink("正在准备测试: " + Name);
            prepared = await _workspace.PrepareAsync(Path, _testingRoot(), manualRelativePath: _artifact.LaunchOverrideRelative);
            _artifact.TestingPath = prepared.TestingPath;
            _artifact.TestingRelativePath = PathRebaseService.TryMakeRelative(_root(), prepared.TestingPath);
            _library.SetTestingPath(Path, prepared.TestingPath, _root());
            await _library.SaveAsync();
        }
        catch (Exception ex)
        {
            _dialogs.Error("准备测试失败", ex.Message);
            return;
        }

        if (string.IsNullOrWhiteSpace(prepared.LaunchPath))
        {
            _dialogs.Info("按规则没有找到启动文件", "测试包已解压。请手动指定本版本的启动文件。");
            var manuallyChosen = ChooseLaunchFile(prepared.TestingPath);
            if (string.IsNullOrWhiteSpace(manuallyChosen)) { await _refreshAll(); return; }
            prepared = prepared with { LaunchPath = manuallyChosen };
            var relative = System.IO.Path.GetRelativePath(prepared.TestingPath, manuallyChosen);
            _library.SetLaunchOverride(Path, relative);
            _artifact.LaunchOverrideRelative = relative;
            await _library.SaveAsync();
        }

        try
        {
            _library.MarkTestStarted(Path);
            _artifact.TestStatus = "测试中";
            await _library.SaveAsync();
            Launch(prepared.LaunchPath);
            _statusSink($"测试中: {Name} · {System.IO.Path.GetFileName(prepared.LaunchPath)}");
            await _refreshAll();
        }
        catch (Exception ex)
        {
            _library.MarkTestStatus(Path, "待测试");
            _artifact.TestStatus = "待测试";
            await _library.SaveAsync();
            _dialogs.Error("启动测试失败", ex.Message);
        }
    }

    private void OpenLocation() => OpenExplorerSelection(Path, "文件不存在", "这个原始 ZIP 已经不在磁盘上了。");

    private void OpenTestingFolder()
    {
        var path = ResolveTestingPath();
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
        {
            _dialogs.Info("还没有测试目录", "双击这个版本后会自动解压到 01_Testing。");
            return;
        }
        try { Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true }); }
        catch (Exception ex) { _dialogs.Error("打开失败", ex.Message); }
    }

    private async Task OpenResultAsync()
    {
        var path = GetDraggableResultPath();
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            _dialogs.Info("还没有 Result / 日志", "测试完成并生成 Result 或 .log 日志后，系统会自动显示“已测试”。");
            return;
        }
        OpenExplorerSelection(path, "结果不存在", "记录的 Result / 日志已经不在磁盘上了。");
    }

    private async Task ReextractAsync()
    {
        if (!File.Exists(Path)) { _dialogs.Info("原始 ZIP 不存在", "无法重新解压这个版本。"); return; }
        var existing = ResolveTestingPath();
        if (Directory.Exists(existing) && !_dialogs.Confirm("重新解压", $"重新建立这个版本的测试目录？\n\n{Name}\n\n检测到的 Result / 日志会先保存到 40_Result。")) return;
        try
        {
            await PreserveEvidenceAsync();
            _workspace.DeleteTestingDirectory(existing);
            _library.ClearTestingPath(Path);
            var prepared = await _workspace.PrepareAsync(Path, _testingRoot());
            _artifact.TestingPath = prepared.TestingPath;
            _artifact.TestingRelativePath = PathRebaseService.TryMakeRelative(_root(), prepared.TestingPath);
            _library.SetTestingPath(Path, prepared.TestingPath, _root());
            _library.MarkTestStatus(Path, "待测试");
            _artifact.TestStatus = "待测试";
            await _library.SaveAsync();
            _statusSink("已重新解压，双击即可测试: " + Name);
            await _refreshAll();
        }
        catch (Exception ex) { _dialogs.Error("重新解压失败", ex.Message); }
    }

    private async Task DeleteTestingAsync()
    {
        var testing = ResolveTestingPath();
        if (string.IsNullOrWhiteSpace(testing) || !Directory.Exists(testing))
        {
            _dialogs.Info("没有测试目录", "这个版本目前没有可删除的 01_Testing 解压目录。");
            return;
        }
        if (!_dialogs.Confirm("删除测试目录", $"只删除解压出来的测试目录？\n\n{Name}\n\n原始 ZIP 会保留；检测到的 Result / 日志会先保存到 40_Result。")) return;
        try
        {
            await PreserveEvidenceAsync();
            _workspace.DeleteTestingDirectory(testing);
            _library.ClearTestingPath(Path);
            _artifact.TestingPath = "";
            _artifact.TestingRelativePath = "";
            await _library.SaveAsync();
            _statusSink("已删除测试目录，原始 ZIP 保留: " + Name);
            await _refreshAll();
        }
        catch (Exception ex) { _dialogs.Error("删除测试目录失败", ex.Message); }
    }

    private void EditNotes()
    {
        var value = _dialogs.EditText("编辑备注", "备注", _artifact.Notes, true);
        if (value is null) return;
        _artifact.Notes = value;
        _library.SetNotes(Path, value);
        OnPropertyChanged(nameof(Notes));
        OnPropertyChanged(nameof(NotesToolTip));
        OnPropertyChanged(nameof(FileNameToolTip));
        _ = SaveMetadataAsync("备注已保存");
    }

    private async Task ArchiveAsync()
    {
        if (IsProtected) { _dialogs.Info("已锁定", "请先右键选择“取消锁定”，再移到历史归档。"); return; }
        if (!_dialogs.Confirm("移到历史归档", $"把这个版本移到历史归档？\n\n{Name}")) return;
        try
        {
            await _organizer.ArchiveAsync(Path);
            _statusSink("已移到历史归档: " + Name);
            await _refreshAll();
        }
        catch (Exception ex) { _dialogs.Error("归档失败", ex.Message); }
    }

    private async Task DeleteDuplicateCopyAsync()
    {
        if (!IsDuplicate) return;
        if (IsProtected) { _dialogs.Info("已锁定", "请先右键选择“取消锁定”，再删除此副本。"); return; }
        if (!_dialogs.Confirm("删除此副本", $"只删除当前重复副本？\n\n{Name}\n\n原始版本、测试目录和 Result / 日志不会删除。")) return;
        try
        {
            await _organizer.DeleteAsync(Path);
            _statusSink("已删除重复副本: " + Name);
            await _refreshAll();
        }
        catch (Exception ex) { _dialogs.Error("删除副本失败", ex.Message); }
    }

    private async Task DeleteVersionAsync()
    {
        if (IsProtected) { _dialogs.Info("已锁定", "请先右键选择“取消锁定”，再删除此版本。"); return; }
        if (!_dialogs.Confirm("删除此版本", $"删除这个版本的原始 ZIP + 测试目录？\n\n{Name}\n\nResult / 日志默认保留到 40_Result，不会一起删除。")) return;
        try
        {
            var testing = ResolveTestingPath();
            await PreserveEvidenceAsync();
            _workspace.DeleteTestingDirectory(testing);
            await _organizer.DeleteAsync(Path);
            _statusSink("已删除此版本，Result / 日志已保留: " + Name);
            await _refreshAll();
        }
        catch (Exception ex) { _dialogs.Error("删除版本失败", ex.Message); }
    }

    private async Task<string> PreserveEvidenceAsync()
    {
        var testing = ResolveTestingPath();
        if (string.IsNullOrWhiteSpace(testing) || !Directory.Exists(testing)) return ExistingResultPath();
        var current = _library.ByPath(Path) ?? _artifact;
        var preserved = await _results.PreserveEvidenceAsync(testing, current, _resultRoot(), preferredPath: GetDraggableResultPath());
        if (string.IsNullOrWhiteSpace(preserved)) return ExistingResultPath();
        _library.SetTestEvidence(Path, preserved, _root(), current.LastTestedAt);
        _artifact.ResultPath = preserved;
        _artifact.ResultRelativePath = PathRebaseService.TryMakeRelative(_root(), preserved);
        _artifact.LastTestedAt = string.IsNullOrWhiteSpace(current.LastTestedAt) ? DateTimeOffset.Now.ToString("O") : current.LastTestedAt;
        OnPropertyChanged(nameof(ResultPath)); OnPropertyChanged(nameof(HasResult)); OnPropertyChanged(nameof(ResultHint));
        return preserved;
    }

    private async Task<string> ResolveResultPathAsync()
    {
        var testing = ResolveTestingPath();
        var current = _library.ByPath(Path) ?? _artifact;

        // Re-resolve at click time as well as drag time so a Result ZIP that was
        // created after the first log automatically supersedes the cached log.
        var preferred = _results.ResolvePreferredDragPath(current, testing, _resultRoot());
        if (!string.IsNullOrWhiteSpace(preferred) && File.Exists(preferred))
        {
            if (!string.Equals(current.ResultPath, preferred, StringComparison.OrdinalIgnoreCase))
            {
                var testedAt = File.GetLastWriteTimeUtc(preferred).ToString("O");
                _library.SetTestEvidence(Path, preferred, _root(), testedAt);
                await _library.SaveAsync();
                _artifact.ResultPath = preferred;
                _artifact.ResultRelativePath = PathRebaseService.TryMakeRelative(_root(), preferred);
                _artifact.TestStatus = "已测试";
                OnPropertyChanged(nameof(ResultPath)); OnPropertyChanged(nameof(HasResult)); OnPropertyChanged(nameof(ResultHint)); OnPropertyChanged(nameof(TestStatus));
            }
            return preferred;
        }

        var existing = ExistingResultPath();
        if (!string.IsNullOrWhiteSpace(existing)) return existing;
        if (string.IsNullOrWhiteSpace(testing) || !Directory.Exists(testing)) return "";
        var evidence = await _results.FindEvidenceAsync(testing, current);
        if (evidence is null) return "";
        _library.SetTestEvidence(Path, evidence.Path, _root(), evidence.LastWriteTimeUtc.ToString("O"));
        await _library.SaveAsync();
        _artifact.ResultPath = evidence.Path;
        _artifact.ResultRelativePath = PathRebaseService.TryMakeRelative(_root(), evidence.Path);
        _artifact.TestStatus = "已测试";
        OnPropertyChanged(nameof(ResultPath)); OnPropertyChanged(nameof(HasResult)); OnPropertyChanged(nameof(ResultHint)); OnPropertyChanged(nameof(TestStatus));
        return evidence.Path;
    }

    private string ExistingResultPath()
    {
        if (!string.IsNullOrWhiteSpace(_artifact.ResultPath) && File.Exists(_artifact.ResultPath)) return _artifact.ResultPath;
        var current = _library.ByPath(Path);
        return current is not null && !string.IsNullOrWhiteSpace(current.ResultPath) && File.Exists(current.ResultPath) ? current.ResultPath : "";
    }

    private string ResolveTestingPath()
    {
        if (!string.IsNullOrWhiteSpace(_artifact.TestingPath) && Directory.Exists(_artifact.TestingPath)) return _artifact.TestingPath;
        var current = _library.ByPath(Path);
        if (current is not null && !string.IsNullOrWhiteSpace(current.TestingPath) && Directory.Exists(current.TestingPath)) return current.TestingPath;
        if (!File.Exists(Path)) return "";
        var derived = System.IO.Path.Combine(_testingRoot(), System.IO.Path.GetFileNameWithoutExtension(Path));
        return Directory.Exists(derived) ? derived : "";
    }

    private static void Launch(string launchPath)
    {
        var extension = System.IO.Path.GetExtension(launchPath).ToLowerInvariant();
        var working = System.IO.Path.GetDirectoryName(launchPath) ?? Environment.CurrentDirectory;
        ProcessStartInfo info = extension switch
        {
            ".cmd" or ".bat" => new ProcessStartInfo("cmd.exe", $"/C call \"{launchPath}\"") { WorkingDirectory = working, UseShellExecute = true },
            ".ps1" => new ProcessStartInfo("powershell.exe", $"-ExecutionPolicy Bypass -File \"{launchPath}\"") { WorkingDirectory = working, UseShellExecute = true },
            ".exe" => new ProcessStartInfo(launchPath) { WorkingDirectory = working, UseShellExecute = true },
            _ => throw new InvalidOperationException("不支持的启动入口: " + extension)
        };
        Process.Start(info);
    }

    private void OpenExplorerSelection(string path, string missingTitle, string missingMessage)
    {
        try
        {
            if (File.Exists(path))
            {
                Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = true });
                return;
            }
            var dir = Directory.Exists(path) ? path : System.IO.Path.GetDirectoryName(path);
            if (!string.IsNullOrWhiteSpace(dir) && Directory.Exists(dir))
                Process.Start(new ProcessStartInfo("explorer.exe", $"\"{dir}\"") { UseShellExecute = true });
            else
                _dialogs.Info(missingTitle, missingMessage);
        }
        catch (Exception ex) { _dialogs.Error("打开失败", ex.Message); }
    }

    private async Task SaveMetadataAsync(string message)
    {
        try
        {
            await _library.SaveAsync();
            _statusSink(message);
        }
        catch (Exception ex) { _statusSink("保存失败: " + ex.Message); }
    }

    private object? BuildTranslatedFieldToolTip(string original, bool translated)
    {
        if (!translated || string.IsNullOrWhiteSpace(original)) return null;
        var parts = new List<string> { $"原文：{original}" };
        if (!string.IsNullOrWhiteSpace(_artifact.Notes)) parts.Add($"备注：{_artifact.Notes}");
        return string.Join("\n\n", parts);
    }

    private static string FormatTime(string importedAt, string buildDate)
    {
        if (DateTimeOffset.TryParse(importedAt, out var imported)) return imported.LocalDateTime.ToString("MM-dd HH:mm");
        if (DateTimeOffset.TryParse(buildDate, out var build)) return build.LocalDateTime.ToString("MM-dd HH:mm");
        return "—";
    }
}
