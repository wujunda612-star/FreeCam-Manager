FreeCam Manager V3.9.19 BackupFix Test1 — isolated source
Base: frozen V3.9.18 Git blob 9a8be54964a7710aabed3068a23e72b0f0160ea3
Scope: backup sidecar rotation cleanup, clickable testing folder icon, four hidden context-menu actions.
This source profile uses independent AppData and disables watcher/updater/startup maintenance. Do not operate destructively on physical D:\FreeCam files referenced by cloned records. SQLite historical orphan cleanup is an explicit, separately confirmed tool in the accompanying local Test1 installer ZIP.
Windows .NET 8 SDK required; Windows compile and real UI validation are pending. V3.9.18 Stable and manager/update.json remain unchanged.
