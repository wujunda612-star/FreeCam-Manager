using System.Windows.Controls;
namespace FreeCamManager.Views;
public partial class HomeView : UserControl { public HomeView() => InitializeComponent(); }
