using System.Windows.Controls;
namespace FreeCamManager.Views;
public partial class SettingsView : UserControl { public SettingsView() => InitializeComponent(); }
