using System.Windows.Controls;
namespace FreeCamManager.Views;
public partial class StableView : UserControl { public StableView() => InitializeComponent(); }
