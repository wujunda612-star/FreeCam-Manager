using System.Collections.ObjectModel;
using System.Windows.Input;
using FreeCamManager.Core.Models;
using FreeCamManager.Core.Services;
using FreeCamManager.Services;

namespace FreeCamManager.ViewModels;

public sealed class HistoryViewModel : ObservableObject
{
    private readonly Func<IReadOnlyList<Artifact>> _snapshot;
    private readonly LibraryService _library;
    private readonly OrganizerService _organizer;
    private readonly ClassificationService _classification;
    private readonly UserDialogService _dialogs;
    private readonly Func<Task> _refreshAll;
    private readonly Action<string> _statusSink;
    private readonly AppSettings _settings;
    private readonly SettingsService _settingsService;
    private readonly FilenameAliasService _filenameAliases;
    private string _searchText = "";
    private string _sortMode = "最新优先";
    private ArtifactRowViewModel? _selectedRow;
    private double _fileColumnWidth;
    private double _featureColumnWidth;
    private double _stageColumnWidth;
    private bool _fileColumnCustomized;

    public HistoryViewModel(Func<IReadOnlyList<Artifact>> snapshot, LibraryService library, OrganizerService organizer,
        ClassificationService classification, UserDialogService dialogs, Func<Task> refreshAll, Action<string> statusSink,
        AppSettings settings, SettingsService settingsService, FilenameAliasService filenameAliases)
    {
        _snapshot = snapshot; _library = library; _organizer = organizer; _classification = classification;
        _dialogs = dialogs; _refreshAll = refreshAll; _statusSink = statusSink; _settings = settings; _settingsService = settingsService; _filenameAliases = filenameAliases;
        _fileColumnCustomized = settings.HistoryFileColumnWidth >= 180;
        _fileColumnWidth = _fileColumnCustomized ? settings.HistoryFileColumnWidth : 180;
        _featureColumnWidth = Math.Max(60, settings.HistoryFeatureColumnWidth);
        _stageColumnWidth = Math.Max(52, settings.HistoryStageColumnWidth);
        RefreshCommand = new AsyncRelayCommand(_ => _refreshAll());
    }

    public ObservableCollection<ArtifactRowViewModel> Items { get; } = [];
    public IReadOnlyList<string> SortOptions { get; } = ["最新优先", "最旧优先", "星级优先"];
    public ICommand RefreshCommand { get; }
    public ArtifactRowViewModel? SelectedRow { get => _selectedRow; set => SetProperty(ref _selectedRow, value); }
    public string SearchText { get => _searchText; set { if (SetProperty(ref _searchText, value)) Refresh(); } }
    public string SortMode { get => _sortMode; set { if (SetProperty(ref _sortMode, value)) Refresh(); } }
    public double FileColumnWidth { get => _fileColumnWidth; private set => SetProperty(ref _fileColumnWidth, Math.Max(180, value)); }
    public double FeatureColumnWidth { get => _featureColumnWidth; private set => SetProperty(ref _featureColumnWidth, Math.Max(60, value)); }
    public double StageColumnWidth { get => _stageColumnWidth; private set => SetProperty(ref _stageColumnWidth, Math.Max(52, value)); }

    public void SetAutoFileColumnWidth(double availableWidth)
    {
        if (_fileColumnCustomized || availableWidth <= 0) return;
        const double fixedColumns = 94 + 86 + 86 + 108 + 40 + 82;
        FileColumnWidth = Math.Max(180, availableWidth - fixedColumns - FeatureColumnWidth - StageColumnWidth);
    }

    public void AdjustFileColumnWidth(double delta)
    {
        _fileColumnCustomized = true;
        FileColumnWidth += delta;
        _settings.HistoryFileColumnWidth = FileColumnWidth;
    }

    public void AdjustFeatureColumnWidth(double delta)
    {
        FeatureColumnWidth += delta;
        _settings.HistoryFeatureColumnWidth = FeatureColumnWidth;
    }

    public void AdjustStageColumnWidth(double delta)
    {
        StageColumnWidth += delta;
        _settings.HistoryStageColumnWidth = StageColumnWidth;
    }

    public async Task PersistColumnWidthsAsync()
    {
        _settings.HistoryFileColumnWidth = _fileColumnCustomized ? FileColumnWidth : 0;
        _settings.HistoryFeatureColumnWidth = FeatureColumnWidth;
        _settings.HistoryStageColumnWidth = StageColumnWidth;
        try { await _settingsService.SaveAsync(AppPaths.SettingsFile, _settings); }
        catch (Exception ex) { _statusSink("历史列宽保存失败: " + ex.Message); }
    }

    public void Refresh()
    {
        var selectedPath = SelectedRow?.Path;
        IEnumerable<Artifact> query = _snapshot().Where(a => !_classification.IsManagerArtifact(a));
        var q = SearchText.Trim();
        if (q.Length > 0) query = query.Where(a => Match(a, q));
        query = SortMode switch
        {
            "最旧优先" => query.OrderBy(a => ParseTime(a.ImportedAt, a.BuildDate)),
            "星级优先" => query.OrderByDescending(a => a.Rating).ThenByDescending(a => ParseTime(a.ImportedAt, a.BuildDate)),
            _ => query.OrderByDescending(a => ParseTime(a.ImportedAt, a.BuildDate))
        };
        Items.Clear();
        foreach (var a in query) Items.Add(new ArtifactRowViewModel(a, _library, _organizer, _classification, _dialogs, _statusSink, _refreshAll,
            () => _settings.HideFreeCamPrefix, () => _settings.DiscardAutoDeleteDays, _filenameAliases.Translate, () => _settings.ShowFilenameAliases,
            () => _settings.ShowFeatureAliases, () => _settings.ShowStageAliases));
        SelectedRow = Items.FirstOrDefault(x => string.Equals(x.Path, selectedPath, StringComparison.OrdinalIgnoreCase));
    }

    private bool Match(Artifact a, string q)
    {
        var translated = _filenameAliases.Translate(a.Name);
        var translatedFeature = _filenameAliases.Translate(a.Feature);
        var translatedStage = _filenameAliases.Translate(a.Stage);
        var fields = new[] { a.Name, translated, a.Base, a.Feature, translatedFeature, a.Stage, translatedStage, a.Category, a.BuildType, a.BuildId, a.Commit, a.ManualStatus, a.TestStatus, a.Notes };
        return fields.Any(x => !string.IsNullOrWhiteSpace(x) && x.Contains(q, StringComparison.OrdinalIgnoreCase));
    }

    private static DateTimeOffset ParseTime(string imported, string build) => DateTimeOffset.TryParse(imported, out var t) ? t : DateTimeOffset.TryParse(build, out t) ? t : DateTimeOffset.MinValue;
}
