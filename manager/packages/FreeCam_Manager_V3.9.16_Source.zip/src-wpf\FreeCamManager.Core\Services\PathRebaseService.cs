using FreeCamManager.Core.Models;

namespace FreeCamManager.Core.Services;

/// <summary>
/// Keeps persisted artifact paths portable when the FreeCam root folder is moved.
/// V3.9.12 avoids the old O(records x recursive directory scan) fallback: when an
/// old record has lost its relative path, the managed tree is indexed by exact
/// filename at most once for the whole repair pass.
/// </summary>
public sealed class PathRebaseService
{
    private static readonly string[] RootMarkers =
    [
        "00_Downloa", "01_Testing", "10_Stable", "20_Feature", "30_Experiment",
        "40_Result", "50_Manager", "60_索引库", "80_Archive", "90_Unknown", "Logs"
    ];

    // Name fallback is only for old artifact records. Do not crawl Manager source
    // trees, logs, inbox, or extracted Testing workspaces for every startup repair.
    private static readonly string[] FallbackSearchMarkers =
    [
        "10_Stable", "20_Feature", "30_Experiment", "40_Result", "80_Archive", "90_Unknown"
    ];

    public async Task<int> RepairLibraryPathsAsync(LibraryService library, string root, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(root)) return 0;
        var repaired = 0;
        Dictionary<string, string?>? uniqueFileIndex = null;

        foreach (var original in library.Snapshot())
        {
            ct.ThrowIfCancellationRequested();
            var item = original.Clone();
            var changed = false;

            var resolvedPath = ResolveFileFast(item.Path, item.RelativePath, item.Name, root, ref uniqueFileIndex, ct);
            if (!string.IsNullOrWhiteSpace(resolvedPath) && !SamePath(item.Path, resolvedPath))
            {
                item.Path = resolvedPath;
                changed = true;
            }
            var relative = TryMakeRelative(root, item.Path);
            if (!string.IsNullOrWhiteSpace(relative) && !string.Equals(item.RelativePath, relative, StringComparison.OrdinalIgnoreCase))
            {
                item.RelativePath = relative;
                changed = true;
            }

            // Testing folders are deterministic. Never recursively search the whole
            // tree for a directory name; relative/inferred paths are enough.
            var resolvedTesting = ResolveDirectoryFast(item.TestingPath, item.TestingRelativePath, root);
            if (!string.IsNullOrWhiteSpace(resolvedTesting) && !SamePath(item.TestingPath, resolvedTesting))
            {
                item.TestingPath = resolvedTesting;
                changed = true;
            }
            var testingRelative = TryMakeRelative(root, item.TestingPath);
            if (!string.IsNullOrWhiteSpace(testingRelative) && !string.Equals(item.TestingRelativePath, testingRelative, StringComparison.OrdinalIgnoreCase))
            {
                item.TestingRelativePath = testingRelative;
                changed = true;
            }

            var resultName = Path.GetFileName(item.ResultPath);
            var resolvedResult = ResolveFileFast(item.ResultPath, item.ResultRelativePath, resultName, root, ref uniqueFileIndex, ct);
            if (!string.IsNullOrWhiteSpace(resolvedResult) && !SamePath(item.ResultPath, resolvedResult))
            {
                item.ResultPath = resolvedResult;
                changed = true;
            }
            var resultRelative = TryMakeRelative(root, item.ResultPath);
            if (!string.IsNullOrWhiteSpace(resultRelative) && !string.Equals(item.ResultRelativePath, resultRelative, StringComparison.OrdinalIgnoreCase))
            {
                item.ResultRelativePath = resultRelative;
                changed = true;
            }

            if (!changed) continue;
            if (!library.ReplacePath(original.Path, item)) library.Upsert(item);
            repaired++;
        }

        if (repaired > 0) await library.SaveAsync(ct).ConfigureAwait(false);
        return repaired;
    }

    public static string TryMakeRelative(string root, string path)
    {
        if (string.IsNullOrWhiteSpace(root) || string.IsNullOrWhiteSpace(path)) return "";
        try
        {
            var fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            var fullPath = Path.GetFullPath(path);
            if (!fullPath.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase)) return "";
            return Path.GetRelativePath(root, fullPath);
        }
        catch { return ""; }
    }

    // Public compatibility helpers keep their previous semantics without using the
    // per-record recursive fallback. They are intentionally conservative.
    public static string ResolveFile(string storedPath, string relativePath, string name, string root)
        => ResolveByKnownLocation(storedPath, relativePath, root, File.Exists);

    public static string ResolveDirectory(string storedPath, string relativePath, string root)
        => ResolveByKnownLocation(storedPath, relativePath, root, Directory.Exists);

    private static string ResolveFileFast(
        string storedPath, string relativePath, string name, string root,
        ref Dictionary<string, string?>? uniqueFileIndex, CancellationToken ct)
    {
        var known = ResolveByKnownLocation(storedPath, relativePath, root, File.Exists);
        if (!string.IsNullOrWhiteSpace(known) && File.Exists(known)) return known;

        if (string.IsNullOrWhiteSpace(name) || !Directory.Exists(root)) return storedPath ?? "";

        // Last-resort compatibility for old records that lost both their valid
        // absolute path and root-relative locator. Build one exact-name index once,
        // instead of recursively scanning every managed root once per database row.
        uniqueFileIndex ??= BuildUniqueFileIndex(root, ct);
        return uniqueFileIndex.TryGetValue(name, out var match) && !string.IsNullOrWhiteSpace(match)
            ? match
            : storedPath ?? "";
    }

    private static string ResolveDirectoryFast(string storedPath, string relativePath, string root)
        => ResolveByKnownLocation(storedPath, relativePath, root, Directory.Exists);

    private static string ResolveByKnownLocation(string storedPath, string relativePath, string root, Func<string, bool> exists)
    {
        foreach (var rel in CandidateRelativePaths(storedPath, relativePath))
        {
            var candidate = Path.Combine(root, rel);
            if (exists(candidate)) return candidate;
        }

        if (!string.IsNullOrWhiteSpace(storedPath) && exists(storedPath)) return storedPath;
        return storedPath ?? "";
    }

    private static Dictionary<string, string?> BuildUniqueFileIndex(string root, CancellationToken ct)
    {
        var index = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        foreach (var marker in FallbackSearchMarkers)
        {
            ct.ThrowIfCancellationRequested();
            var managedRoot = Path.Combine(root, marker);
            if (!Directory.Exists(managedRoot)) continue;

            IEnumerable<string> files;
            try { files = Directory.EnumerateFiles(managedRoot, "*", SearchOption.AllDirectories); }
            catch (UnauthorizedAccessException) { continue; }
            catch (IOException) { continue; }

            try
            {
                foreach (var path in files)
                {
                    ct.ThrowIfCancellationRequested();
                    var fileName = Path.GetFileName(path);
                    if (string.IsNullOrWhiteSpace(fileName)) continue;
                    if (!index.TryAdd(fileName, path))
                    {
                        // Ambiguous exact names are deliberately not guessed.
                        if (!SamePath(index[fileName] ?? "", path)) index[fileName] = null;
                    }
                }
            }
            catch (UnauthorizedAccessException) { }
            catch (IOException) { }
        }
        return index;
    }

    private static IEnumerable<string> CandidateRelativePaths(string storedPath, string relativePath)
    {
        if (!string.IsNullOrWhiteSpace(relativePath)) yield return NormalizeRelative(relativePath);
        var inferred = InferManagedTail(storedPath);
        if (!string.IsNullOrWhiteSpace(inferred) && !string.Equals(inferred, relativePath, StringComparison.OrdinalIgnoreCase))
            yield return inferred;
    }

    private static string InferManagedTail(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return "";
        var unified = path.Replace('\\', '/');
        foreach (var marker in RootMarkers)
        {
            var token = "/" + marker + "/";
            var index = unified.IndexOf(token, StringComparison.OrdinalIgnoreCase);
            if (index >= 0) return NormalizeRelative(unified[(index + 1)..]);
            if (unified.EndsWith("/" + marker, StringComparison.OrdinalIgnoreCase)) return marker;
        }
        return "";
    }

    private static string NormalizeRelative(string value)
        => value.Replace('\\', Path.DirectorySeparatorChar).Replace('/', Path.DirectorySeparatorChar)
            .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

    private static bool SamePath(string a, string b)
    {
        if (string.IsNullOrWhiteSpace(a) || string.IsNullOrWhiteSpace(b))
            return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        try { return string.Equals(Path.GetFullPath(a), Path.GetFullPath(b), StringComparison.OrdinalIgnoreCase); }
        catch { return string.Equals(a, b, StringComparison.OrdinalIgnoreCase); }
    }
}
